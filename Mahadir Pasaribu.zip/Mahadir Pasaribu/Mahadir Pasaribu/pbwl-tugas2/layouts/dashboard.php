<!DOCTYPE html>
<html>

<head>
	<title>Praktikum SI-MVC</title>
	<link rel="stylesheet" href="<?php echo AST . "/css/style.css"; ?>">
</head>

<body>
	<h1>Template Dashboard</h1>
	<?php require_once ROOT . "app/views/" . $view . ".php"; ?>
</body>

</html>